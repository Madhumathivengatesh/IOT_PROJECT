const int led1 = 4;
const int led2 = 5;
const int buttonPin = 2;

// LED1 blinking
unsigned long previousMillis = 0;
const unsigned long interval = 1000;
bool led1State = LOW;

// Interrupt variables
volatile bool interruptFlag = false;

// LED2 timing
bool led2On = false;
unsigned long led2StartTime = 0;

void IRAM_ATTR buttonISR() {
  interruptFlag = true;   // Only set a flag
}

void setup() {

  pinMode(led1, OUTPUT);
  pinMode(led2, OUTPUT);
  pinMode(buttonPin, INPUT_PULLUP);

  attachInterrupt(
    digitalPinToInterrupt(buttonPin),
    buttonISR,
    FALLING
  );

}

void loop() {

  unsigned long currentMillis = millis();

  // LED1 blinks continuously
  if (currentMillis - previousMillis >= interval) {

    previousMillis = currentMillis;

    led1State = !led1State;

    digitalWrite(led1, led1State);
  }

  // If interrupt occurred
  if (interruptFlag) {

    interruptFlag = false;

    digitalWrite(led2, HIGH);

    led2On = true;

    led2StartTime = currentMillis;
  }

  // Keep LED2 ON for 500 ms
  if (led2On && (currentMillis - led2StartTime >= 500)) {

    digitalWrite(led2, LOW);

    led2On = false;
  }

}