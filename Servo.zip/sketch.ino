#include <ESP32Servo.h>

Servo myServo;

const int servoPin = 13;
const int switchPin = 4;

void setup() {
  myServo.attach(servoPin);
  pinMode(switchPin, INPUT_PULLUP);
}

void loop() {
  int switchState = digitalRead(switchPin);

  if (switchState == LOW) {
    myServo.write(90);   // Servo ON position
  } 
  else {
    myServo.write(0);    // Servo OFF position
  }

  delay(100);
}