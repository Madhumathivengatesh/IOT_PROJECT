from pathlib import Path
root=Path(__file__).resolve().parents[1]
required=['Dockerfile','docker-compose.yml','requirements.txt','README.md','IMPLEMENTATION_GUIDE.txt','app/app.py','app/engine.py','app/database.py','web/templates/index.html']
missing=[x for x in required if not (root/x).exists()]
assert not missing, missing
print('Project structure OK')
