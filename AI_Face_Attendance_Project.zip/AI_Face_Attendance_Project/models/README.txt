Required official OpenCV Zoo model files:

models/face_detection/face_detection_yunet_2023mar.onnx
models/face_recognition/face_recognition_sface_2021dec.onnx

The ZIP does not include these binary weights because the available project archive did not contain the original model binaries. Download the exact filenames from the official OpenCV Zoo repository and place them at the paths above before docker compose up.
