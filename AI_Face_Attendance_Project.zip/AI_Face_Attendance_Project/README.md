# AI Face Attendance System

Docker-based real-time face attendance using DroidCam/IP camera, OpenCV YuNet detection, SFace recognition, Flask, SQLite and CSV.

## Features
- Dark glass-style AI Attendance dashboard
- Employee registration from photo
- YuNet face detection with NMS
- SFace cosine-similarity recognition
- First confirmed appearance: IN
- Person must leave the view for at least 5 seconds before the next appearance can create OUT/IN/OUT events
- Unknown faces shown as UNKNOWN and saved with date/time when they are sufficiently different from previous unknown embeddings
- Unknown count represents unique unknown embeddings rather than every video frame
- Daily attendance starts with registered employees as ABSENT
- Midnight starts a new attendance day
- SQLite database plus CSV event export
- Docker Compose persistent folders

## 1. Models
Place these exact files in the model folders:
`face_detection_yunet_2023mar.onnx` and `face_recognition_sface_2021dec.onnx`. Official OpenCV Zoo pages are linked in `MODEL_SOURCES.txt`.

## 2. Configure camera
Copy `.env.example` to `.env`. For DroidCam, set `CAMERA_URL` to your phone URL, for example `http://PHONE_IP:4747/video`. For a USB webcam use `CAMERA_SOURCE=webcam` and `WEBCAM_INDEX=0`.

## 3. Run
PowerShell:
```powershell
docker compose up -d --build
docker compose ps
docker compose logs --tail=50
```
Open `http://localhost:8000`.

## 4. Registration
Click **Register Employee**, enter an employee ID and full name, and upload a clear single-face photo. The face embedding is stored in SQLite and the photo is stored under `known_persons`.

## 5. Attendance logic
At the start of a day each active employee is ABSENT. First confirmed recognition changes ABSENT -> IN. Continuous presence does not create repeated events. After the person is absent for at least `REDETECTION_SECONDS` (default 5), the next recognition changes IN -> OUT; the next separated recognition changes OUT -> IN. Every event is stored in SQLite and exported to CSV.

## 6. Troubleshooting
- Missing model error: verify both ONNX files and paths.
- Registration error: use a clear photo containing exactly one face.
- Camera offline: test the phone URL from the host browser and ensure phone and PC are on the same reachable network.
- Slow video: use 640x480, `PROCESS_EVERY_N_FRAMES=2`, and avoid processing every frame.

## Project flow
Phone/DroidCam -> OpenCV VideoCapture -> YuNet -> SFace -> attendance engine -> SQLite/CSV -> Flask -> browser.
