Copy-Item .env.example .env -ErrorAction SilentlyContinue
docker compose up -d --build
docker compose ps
Write-Host "Open http://localhost:8000"
