import os,threading,base64,cv2,numpy as np
from flask import Flask,render_template,request,jsonify,Response,send_file
from .engine import Engine
from . import database as db
from .config import CSV_PATH,UNKNOWN_DIR
app=Flask(__name__,template_folder='../web/templates')
engine=None
try: engine=Engine()
except Exception as e: engine_error=str(e)
else: engine.start()
@app.get('/')
def index(): return render_template('index.html')
@app.get('/api/live/status')
def status():
 return jsonify({'running':bool(engine and engine.running),'camera_connected':bool(engine and engine.cap and engine.cap.isOpened()),'fps':round(engine.fps,1) if engine else 0,'employees_loaded':len(engine.people) if engine else 0,'faces':len(engine.results) if engine else 0,'error':globals().get('engine_error')})
@app.get('/api/live/results')
def results(): return jsonify(engine.results if engine else [])
@app.get('/api/live/video')
def video(): return Response(engine.mjpeg(),mimetype='multipart/x-mixed-replace; boundary=frame') if engine else ('',503)
@app.post('/api/live/start')
def start():
 if engine: engine.start(); return jsonify({'ok':True})
 return jsonify({'ok':False,'error':engine_error}),500
@app.get('/api/attendance')
def attendance(): return jsonify(db.get_day(request.args.get('date') or __import__('datetime').date.today().isoformat()))
@app.get('/api/history')
def history(): return jsonify(db.history(request.args.get('date')))
@app.get('/api/employees')
def employees(): return jsonify(db.employees())
@app.post('/api/employees')
def add_employee():
 if not engine:return jsonify({'error':engine_error}),500
 eid=request.form.get('employee_id','').strip(); name=request.form.get('name','').strip(); f=request.files.get('photo')
 if not eid or not name or not f:return jsonify({'error':'Employee ID, name and photo are required.'}),400
 if any(x['employee_id']==eid for x in db.employees()):return jsonify({'error':'Employee ID already exists.'}),409
 data=np.frombuffer(f.read(),np.uint8); img=cv2.imdecode(data,cv2.IMREAD_COLOR)
 if img is None:return jsonify({'error':'Invalid image.'}),400
 try:path=engine.register(eid,name,img)
 except Exception as e:return jsonify({'error':str(e)}),400
 return jsonify({'ok':True,'employee_id':eid,'name':name,'photo_path':path})
@app.delete('/api/employees/<eid>')
def remove(eid): db.deactivate(eid); return jsonify({'ok':True})
@app.get('/api/export')
def export(): db.sync_csv(); return send_file(CSV_PATH,as_attachment=True,download_name='attendance_events.csv')
@app.get('/api/unknown')
def unknown():
 rows=db.unknown_rows(); return jsonify({'count':len(rows),'items':rows})
if __name__=='__main__': app.run(host='0.0.0.0',port=8000,threaded=True)
