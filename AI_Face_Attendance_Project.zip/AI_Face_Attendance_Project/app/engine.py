import cv2,numpy as np,threading,time,os
from datetime import datetime,date
from pathlib import Path
from . import database as db
from .config import *
class Engine:
 def __init__(self):
  self.lock=threading.Lock(); self.running=False; self.cap=None; self.frame=None; self.results=[]; self.fps=0; self.frame_no=0; self.last_date=date.today().isoformat(); self.states={}; self.last_unknown=0
  if not YUNET_MODEL.exists() or not SFACE_MODEL.exists(): raise FileNotFoundError('Missing ONNX model(s). See README.md and models/README.txt.')
  self.det=cv2.FaceDetectorYN.create(str(YUNET_MODEL),'',(320,320),DETECTION_THRESHOLD,NMS_THRESHOLD,TOP_K)
  self.rec=cv2.FaceRecognizerSF.create(str(SFACE_MODEL),'')
  db.init(); db.reset_day(self.last_date); self.reload()
 def reload(self):
  self.people=[]
  for r in db.employee_rows():
   emb=np.frombuffer(r['embedding'],dtype=np.float32); self.people.append((r['employee_id'],r['name'],emb))
 def _feature(self,img,face):
  aligned=self.rec.alignCrop(img,face); return self.rec.feature(aligned).astype(np.float32)
 def _match(self,feat):
  best=None
  for eid,name,emb in self.people:
   score=float(self.rec.match(feat,emb,cv2.FaceRecognizerSF_FR_COSINE))
   if best is None or score>best[2]: best=(eid,name,score)
  return best if best and best[2]>=RECOGNITION_THRESHOLD else None
 def register(self,eid,name,img):
  self.det.setInputSize((img.shape[1],img.shape[0])); faces=self.det.detect(img)[1]
  if faces is None or len(faces)==0: raise ValueError('No face detected in registration photo.')
  face=max(faces,key=lambda x:x[2]*x[3]); emb=self._feature(img,face); path=KNOWN_DIR/f'{eid}.jpg'; cv2.imwrite(str(path),img)
  db.add_employee(eid,name,path,emb.tobytes()); self.reload(); return str(path)
 def _attendance(self,eid,name,now):
  day=now.date().isoformat(); t=now.strftime('%H:%M:%S'); s=self.states.setdefault(eid,{'visible':False,'last_seen':0})
  if not s['visible'] and (now.timestamp()-s['last_seen']>=REDETECTION_SECONDS):
   rows=db.get_day(day); row=next((x for x in rows if x['employee_id']==eid),None); action='IN' if not row or row['status'] in ('ABSENT','OUT') and row['status']=='ABSENT' else 'OUT'
   if row and row['status']=='OUT': action='IN'
   db.set_status(eid,day,t,action); s['visible']=True
  else: s['visible']=True
  s['last_seen']=now.timestamp(); return 'IN' if db.get_day(day)[next(i for i,x in enumerate(db.get_day(day)) if x['employee_id']==eid)]['status']=='IN' else 'OUT'
 def process(self,frame):
  now=datetime.now()
  if now.date().isoformat()!=self.last_date: self.last_date=now.date().isoformat(); self.states={}; db.reset_day(self.last_date)
  if self.frame_no%PROCESS_EVERY_N_FRAMES: self.frame_no+=1; return frame
  self.frame_no+=1; h,w=frame.shape[:2]; self.det.setInputSize((w,h)); faces=self.det.detect(frame)[1]; self.results=[]; seen=set()
  if faces is not None:
   for face in faces:
    x,y,fw,fh=map(int,face[:4]); x=max(0,x); y=max(0,y); fw=min(fw,w-x); fh=min(fh,h-y)
    if fw<40 or fh<40: continue
    feat=self._feature(frame,face); m=self._match(feat)
    if m:
     eid,name,score=m; seen.add(eid); self._attendance(eid,name,now); action=db.get_day(now.date().isoformat()); row=next(r for r in action if r['employee_id']==eid); label=f'{name} | {row["status"]}'; self.results.append({'employee_id':eid,'name':name,'score':round(score,3),'action':row['status'],'box':[x,y,fw,fh]}); cv2.rectangle(frame,(x,y),(x+fw,y+fh),(40,210,130),2); cv2.putText(frame,label,(x,y-8),0,0.55,(40,210,130),2)
    else:
     crop=frame[y:y+fh,x:x+fw].copy(); self._unknown(crop,feat,now); self.results.append({'employee_id':None,'name':'UNKNOWN','score':0,'action':'UNKNOWN','box':[x,y,fw,fh]}); cv2.rectangle(frame,(x,y),(x+fw,y+fh),(40,80,230),2); cv2.putText(frame,'UNKNOWN',(x,y-8),0,0.55,(40,80,230),2)
  # mark people absent from view only by state timing; no repeated toggles while continuously visible
  for eid,s in self.states.items():
   if eid not in seen and s['visible'] and now.timestamp()-s['last_seen']>=REDETECTION_SECONDS: s['visible']=False
  return frame
 def _unknown(self,crop,feat,now):
  if now.timestamp()-self.last_unknown<UNKNOWN_SAVE_COOLDOWN:return
  for r in db.unknown_embeddings():
   old=np.frombuffer(r['embedding'],dtype=np.float32); score=float(self.rec.match(feat,old,cv2.FaceRecognizerSF_FR_COSINE))
   if score>=UNKNOWN_SIMILARITY:return
  ts=now.strftime('%Y-%m-%d_%H-%M-%S_%f'); path=UNKNOWN_DIR/f'{ts}.jpg'; cv2.imwrite(str(path),crop); db.add_unknown(now.date().isoformat(),now.strftime('%H:%M:%S'),path,feat.tobytes()); self.last_unknown=now.timestamp()
 def loop(self):
  source=CAMERA_URL if CAMERA_SOURCE=='droidcam' else WEBCAM_INDEX
  self.cap=cv2.VideoCapture(source); self.cap.set(cv2.CAP_PROP_FRAME_WIDTH,FRAME_WIDTH); self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT,FRAME_HEIGHT); last=time.time(); count=0; self.running=True
  while self.running:
   ok,frame=self.cap.read()
   if not ok: time.sleep(.2); continue
   out=self.process(frame)
   with self.lock:self.frame=out.copy(); count+=1; now=time.time();
   if now-last>=1: self.fps=count/(now-last); count=0; last=now
  self.cap.release()
 def start(self):
  if not self.running: threading.Thread(target=self.loop,daemon=True).start()
 def stop(self): self.running=False
 def mjpeg(self):
  while True:
   with self.lock: f=None if self.frame is None else self.frame.copy()
   if f is None: time.sleep(.1); continue
   ok,b=cv2.imencode('.jpg',f,[cv2.IMWRITE_JPEG_QUALITY,75])
   if ok: yield b'--frame\r\nContent-Type: image/jpeg\r\n\r\n'+b.tobytes()+b'\r\n'
