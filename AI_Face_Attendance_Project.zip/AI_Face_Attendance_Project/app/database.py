import sqlite3,csv
from datetime import datetime,date
from pathlib import Path
from .config import DB_PATH,CSV_PATH
SCHEMA="""
CREATE TABLE IF NOT EXISTS employees(employee_id TEXT PRIMARY KEY,name TEXT NOT NULL,photo_path TEXT NOT NULL,embedding BLOB NOT NULL,active INTEGER NOT NULL DEFAULT 1,created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS attendance_days(employee_id TEXT NOT NULL,date TEXT NOT NULL,time_in TEXT,time_out TEXT,status TEXT NOT NULL,PRIMARY KEY(employee_id,date));
CREATE TABLE IF NOT EXISTS events(id INTEGER PRIMARY KEY AUTOINCREMENT,employee_id TEXT NOT NULL,event_date TEXT NOT NULL,event_time TEXT NOT NULL,action TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS unknown_people(id INTEGER PRIMARY KEY AUTOINCREMENT,event_date TEXT NOT NULL,event_time TEXT NOT NULL,image_path TEXT NOT NULL,embedding BLOB NOT NULL);
"""
def conn():
    c=sqlite3.connect(DB_PATH,check_same_thread=False); c.row_factory=sqlite3.Row; return c
def init():
    c=conn(); c.executescript(SCHEMA); c.commit(); c.close(); sync_csv()
def ensure_day(employee_id,day):
    c=conn(); c.execute("INSERT OR IGNORE INTO attendance_days(employee_id,date,status) SELECT employee_id,?, 'ABSENT' FROM employees WHERE employee_id=? AND active=1",(day,employee_id)); c.commit(); c.close()
def reset_day(day):
    c=conn(); c.execute("INSERT OR IGNORE INTO attendance_days(employee_id,date,status) SELECT employee_id,?, 'ABSENT' FROM employees WHERE active=1",(day,)); c.commit(); c.close()
def employees():
    c=conn(); r=c.execute('SELECT employee_id,name,photo_path,active,created_at FROM employees ORDER BY employee_id').fetchall(); c.close(); return [dict(x) for x in r]
def employee_rows():
    c=conn(); r=c.execute('SELECT * FROM employees WHERE active=1 ORDER BY employee_id').fetchall(); c.close(); return [dict(x) for x in r]
def add_employee(eid,name,photo,emb):
    c=conn(); c.execute('INSERT INTO employees VALUES(?,?,?,?,1,?)',(eid,name,str(photo),emb,datetime.now().isoformat(timespec='seconds'))); c.commit(); c.close(); reset_day(date.today().isoformat())
def deactivate(eid):
    c=conn(); c.execute('UPDATE employees SET active=0 WHERE employee_id=?',(eid,)); c.commit(); c.close()
def get_day(day):
    reset_day(day); c=conn(); r=c.execute('SELECT d.*,e.name FROM attendance_days d JOIN employees e ON e.employee_id=d.employee_id WHERE d.date=? ORDER BY d.employee_id',(day,)).fetchall(); c.close(); return [dict(x) for x in r]
def event(eid,day,t,action):
    c=conn(); c.execute('INSERT INTO events(employee_id,event_date,event_time,action) VALUES(?,?,?,?)',(eid,day,t,action)); c.commit(); c.close(); sync_csv()
def set_status(eid,day,t,action):
    ensure_day(eid,day); c=conn()
    if action=='IN': c.execute("UPDATE attendance_days SET time_in=?,status='IN',time_out=NULL WHERE employee_id=? AND date=?",(t,eid,day))
    else: c.execute("UPDATE attendance_days SET time_out=?,status='OUT' WHERE employee_id=? AND date=?",(t,eid,day))
    c.commit(); c.close(); event(eid,day,t,action)
def history(day=None):
    c=conn();
    if day: r=c.execute('SELECT * FROM events WHERE event_date=? ORDER BY id DESC',(day,)).fetchall()
    else: r=c.execute('SELECT * FROM events ORDER BY id DESC LIMIT 500').fetchall()
    c.close(); return [dict(x) for x in r]
def add_unknown(day,t,path,emb):
    c=conn(); c.execute('INSERT INTO unknown_people(event_date,event_time,image_path,embedding) VALUES(?,?,?,?)',(day,t,str(path),emb)); c.commit(); c.close()
def unknown_rows():
    c=conn(); r=c.execute('SELECT * FROM unknown_people ORDER BY id DESC').fetchall(); c.close(); return [dict(x) for x in r]
def unknown_embeddings():
    c=conn(); r=c.execute('SELECT id,embedding FROM unknown_people').fetchall(); c.close(); return r
def sync_csv():
    c=conn(); r=c.execute('SELECT id,employee_id,event_date,event_time,action FROM events ORDER BY id').fetchall(); c.close()
    with open(CSV_PATH,'w',newline='',encoding='utf-8') as f:
        out=csv.writer(f); out.writerow(['id','employee_id','date','time','action']); out.writerows([tuple(x) for x in r])
