import os
from pathlib import Path
BASE_DIR=Path(__file__).resolve().parent.parent
YUNET_MODEL=BASE_DIR/'models/face_detection/face_detection_yunet_2023mar.onnx'
SFACE_MODEL=BASE_DIR/'models/face_recognition/face_recognition_sface_2021dec.onnx'
KNOWN_DIR=BASE_DIR/'known_persons'; UNKNOWN_DIR=BASE_DIR/'unknown_faces'; DATA_DIR=BASE_DIR/'data'; LOG_DIR=BASE_DIR/'logs'
DB_PATH=DATA_DIR/'attendance.db'; CSV_PATH=DATA_DIR/'attendance_events.csv'
CAMERA_SOURCE=os.getenv('CAMERA_SOURCE','droidcam').lower()
CAMERA_URL=os.getenv('CAMERA_URL','http://127.0.0.1:4747/video')
WEBCAM_INDEX=int(os.getenv('WEBCAM_INDEX','0'))
FRAME_WIDTH=int(os.getenv('FRAME_WIDTH','640')); FRAME_HEIGHT=int(os.getenv('FRAME_HEIGHT','480'))
DETECTION_THRESHOLD=float(os.getenv('DETECTION_THRESHOLD','0.60')); NMS_THRESHOLD=float(os.getenv('NMS_THRESHOLD','0.30')); TOP_K=int(os.getenv('TOP_K','5000'))
RECOGNITION_THRESHOLD=float(os.getenv('RECOGNITION_THRESHOLD','0.363'))
REDETECTION_SECONDS=float(os.getenv('REDETECTION_SECONDS','5'))
UNKNOWN_SIMILARITY=float(os.getenv('UNKNOWN_SIMILARITY','0.60'))
UNKNOWN_SAVE_COOLDOWN=float(os.getenv('UNKNOWN_SAVE_COOLDOWN','5'))
PROCESS_EVERY_N_FRAMES=max(1,int(os.getenv('PROCESS_EVERY_N_FRAMES','2')))
for d in [KNOWN_DIR,UNKNOWN_DIR,DATA_DIR,LOG_DIR]: d.mkdir(parents=True,exist_ok=True)
