#include <Wire.h>
#include <LiquidCrystal_I2C.h>
#include <IRremote.hpp>

#define IR_RECEIVE_PIN 15

LiquidCrystal_I2C lcd(0x27, 16, 2);

// Wokwi Remote Commands
#define BTN_UP     24    // Button 2
#define BTN_DOWN   74    // Button 8
#define BTN_OK     56    // Button 5
#define BTN_BACK   194   // Back Button

String menu[] = {
  "Calculator",
  "Stopwatch",
  "Counter",
  "About"
};

int menuIndex = 0;
const int totalMenu = 4;

void showMenu()
{
  lcd.clear();
  lcd.setCursor(0,0);
  lcd.print("Main Menu");

  lcd.setCursor(0,1);
  lcd.print("> ");
  lcd.print(menu[menuIndex]);
}

void calculator()
{
  lcd.clear();
  lcd.print("Calculator");
  lcd.setCursor(0,1);
  lcd.print("Coming Soon");

  while(true)
  {
    if(IrReceiver.decode())
    {
      if(IrReceiver.decodedIRData.command == BTN_BACK)
      {
        IrReceiver.resume();
        break;
      }
      IrReceiver.resume();
    }
  }
}

void stopwatch()
{
  lcd.clear();
  lcd.print("Stopwatch");
  lcd.setCursor(0,1);
  lcd.print("Coming Soon");

  while(true)
  {
    if(IrReceiver.decode())
    {
      if(IrReceiver.decodedIRData.command == BTN_BACK)
      {
        IrReceiver.resume();
        break;
      }
      IrReceiver.resume();
    }
  }
}

void counter()
{
  int value = 0;

  while(true)
  {
    lcd.clear();
    lcd.setCursor(0,0);
    lcd.print("Counter");

    lcd.setCursor(0,1);
    lcd.print("Value: ");
    lcd.print(value);

    while(!IrReceiver.decode());

    int cmd = IrReceiver.decodedIRData.command;

    if(cmd == BTN_UP)
      value++;

    else if(cmd == BTN_DOWN)
      value--;

    else if(cmd == BTN_BACK)
    {
      IrReceiver.resume();
      break;
    }

    IrReceiver.resume();
  }
}

void about()
{
  lcd.clear();
  lcd.print("ESP32 IR Menu");

  lcd.setCursor(0,1);
  lcd.print("Wokwi Project");

  while(true)
  {
    if(IrReceiver.decode())
    {
      if(IrReceiver.decodedIRData.command == BTN_BACK)
      {
        IrReceiver.resume();
        break;
      }

      IrReceiver.resume();
    }
  }
}

void openMenu()
{
  switch(menuIndex)
  {
    case 0:
      calculator();
      break;

    case 1:
      stopwatch();
      break;

    case 2:
      counter();
      break;

    case 3:
      about();
      break;
  }

  showMenu();
}

void setup()
{
  Serial.begin(115200);

  lcd.init();
  lcd.backlight();

  IrReceiver.begin(IR_RECEIVE_PIN, ENABLE_LED_FEEDBACK);

  showMenu();
}

void loop()
{
  if(IrReceiver.decode())
  {
    int command = IrReceiver.decodedIRData.command;

    switch(command)
    {
      case BTN_UP:

        menuIndex--;

        if(menuIndex < 0)
          menuIndex = totalMenu - 1;

        showMenu();

        break;

      case BTN_DOWN:

        menuIndex++;

        if(menuIndex >= totalMenu)
          menuIndex = 0;

        showMenu();

        break;

      case BTN_OK:

        openMenu();

        break;
    }

    IrReceiver.resume();
  }
}