const int ledPin = 4;
const int buttonPin = 2;

volatile bool ledState = false;
volatile unsigned long lastInterrupt = 0;

void IRAM_ATTR buttonISR() {

  unsigned long now = millis();   

  if (now - lastInterrupt > 200) {   

    ledState = !ledState;           
    digitalWrite(ledPin, ledState); 

    lastInterrupt = now;            
  }

}

void setup() {

  pinMode(ledPin, OUTPUT);
  pinMode(buttonPin, INPUT_PULLUP);

  attachInterrupt(
    digitalPinToInterrupt(buttonPin),
    buttonISR,
    CHANGE
  );

}

void loop() {

}