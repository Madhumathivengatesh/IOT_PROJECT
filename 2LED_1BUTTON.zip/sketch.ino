const int led1 = 4;
const int led2 = 5;
const int buttonPin = 2;

bool blinkEnable = false;
bool lastButtonState = HIGH;

bool led1State = LOW;
bool led2State = LOW;

unsigned long previousMillis1 = 0;
unsigned long previousMillis2 = 0;

const unsigned long interval1 = 1000;   // LED1 = 1 second
const unsigned long interval2 = 500;    // LED2 = 0.5 second

unsigned long lastDebounceTime = 0;
const unsigned long debounceDelay = 200;

void setup() {

  pinMode(led1, OUTPUT);
  pinMode(led2, OUTPUT);
  pinMode(buttonPin, INPUT_PULLUP);

  digitalWrite(led1, LOW);
  digitalWrite(led2, LOW);

}

void loop() {

  unsigned long currentMillis = millis();

  // Read Button
  bool currentButtonState = digitalRead(buttonPin);

  // Detect button press (HIGH -> LOW)
  if (lastButtonState == HIGH && currentButtonState == LOW) {

    // Debounce
    if (currentMillis - lastDebounceTime >= debounceDelay) {

      blinkEnable = !blinkEnable;

      if (blinkEnable) {

        // Restart timers
        previousMillis1 = currentMillis;
        previousMillis2 = currentMillis;

      } else {

        // Stop blinking
        digitalWrite(led1, LOW);
        digitalWrite(led2, LOW);

        led1State = LOW;
        led2State = LOW;
      }

      lastDebounceTime = currentMillis;
    }
  }

  lastButtonState = currentButtonState;

  // Blink LEDs only when enabled
  if (blinkEnable) {

    // LED1
    if (currentMillis - previousMillis1 >= interval1) {

      previousMillis1 = currentMillis;

      led1State = !led1State;

      digitalWrite(led1, led1State);
    }

    // LED2
    if (currentMillis - previousMillis2 >= interval2) {

      previousMillis2 = currentMillis;

      led2State = !led2State;

      digitalWrite(led2, led2State);
    }
  }
}