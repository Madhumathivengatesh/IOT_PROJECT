int ledPins[] = {13, 12, 14, 27, 26, 25, 33, 32, 18, 19};

int ledCount = 10;

void setup() {
  for (int i = 0; i < ledCount; i++) {
    pinMode(ledPins[i], OUTPUT);
  }
}

void loop() {

  // Turn ON LEDs one by one
  for (int i = 0; i < ledCount; i++) {
    digitalWrite(ledPins[i], HIGH);
    delay(200);
  }

  delay(500);

  // Turn OFF LEDs one by one
  for (int i = 0; i < ledCount; i++) {
    digitalWrite(ledPins[i], LOW);
    delay(200);
  }

  delay(500);
}