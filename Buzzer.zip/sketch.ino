const int buzzerPin = 5;
const int buttonPin = 4;

void setup() {
  pinMode(buzzerPin, OUTPUT);
  pinMode(buttonPin, INPUT_PULLUP);
}

void loop() {
  int buttonState = digitalRead(buttonPin);

  if (buttonState == LOW) {   // Button pressed
    tone(buzzerPin, 1000);    // Buzzer ON
  } 
  else {
    noTone(buzzerPin);        // Buzzer OFF
  }
}