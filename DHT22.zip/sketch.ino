#include <DHT.h>

#define DHTPIN 15
#define DHTTYPE DHT22

const int ledPin = 2;
const int buttonPin = 4;

DHT dht(DHTPIN, DHTTYPE);

bool ledState = false;
bool lastButtonState = HIGH;

void setup() {
  Serial.begin(115200);

  pinMode(ledPin, OUTPUT);
  pinMode(buttonPin, INPUT_PULLUP);

  dht.begin();
}

void loop() {
  // Toggle LED with button
  bool buttonState = digitalRead(buttonPin);

  if (lastButtonState == HIGH && buttonState == LOW) {
    ledState = !ledState;
    digitalWrite(ledPin, ledState);
    delay(200); // Debounce
  }

  lastButtonState = buttonState;

  // Read DHT22
  float temperature = dht.readTemperature();
  float humidity = dht.readHumidity();

  if (!isnan(temperature) && !isnan(humidity)) {
    Serial.print("Temperature: ");
    Serial.print(temperature);
    Serial.print(" °C  Humidity: ");
    Serial.print(humidity);
    Serial.println(" %");
  } else {
    Serial.println("Failed to read from DHT22!");
  }

  delay(1000);
}