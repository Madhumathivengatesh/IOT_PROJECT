const int ledPin = 4;
const int buttonPin = 2;

bool ledState = false;
bool lastButtonState = LOW;    // idle state is LOW

void setup() {
  pinMode(ledPin, OUTPUT);
  pinMode(buttonPin, INPUT);   // external 10k resistor handles the pull-down
}

void loop() {
  bool currentButtonState = digitalRead(buttonPin);

  if (lastButtonState == LOW && currentButtonState == HIGH) { // press = LOW to HIGH
    ledState = !ledState;
    digitalWrite(ledPin, ledState);
    delay(300); // debounce
  }

  lastButtonState = currentButtonState;
}