const int ledPin = 2;
const int switchPin = 4;

void setup() {
  pinMode(ledPin, OUTPUT);
  pinMode(switchPin, INPUT_PULLUP);
}

void loop() {
  int switchState = digitalRead(switchPin);

  if (switchState == LOW) {  
    digitalWrite(ledPin, HIGH);  // Switch ON
  } else {
    digitalWrite(ledPin, LOW);   // Switch OFF
  }
}