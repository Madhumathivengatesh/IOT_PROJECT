const int ledPin = 4;
const int buttonPin = 2;

bool ledState = false;
bool lastButtonState = HIGH;   // idle state is HIGH

void setup() {
  pinMode(ledPin, OUTPUT);
  pinMode(buttonPin, INPUT);   // external 10k resistor handles the pull-up
}

void loop() {
  bool currentButtonState = digitalRead(buttonPin);

  if (lastButtonState == HIGH && currentButtonState == LOW) { // press = HIGH to LOW
   ledState = !ledState;
    digitalWrite(ledPin, ledState);
    delay(300); // debounce
  }

  lastButtonState = currentButtonState;
}