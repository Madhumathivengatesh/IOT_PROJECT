const int led1 = 4;
const int led2 = 5;

unsigned long previousMillis = 0;

int state = 0;

void setup() {

  pinMode(led1, OUTPUT);
  pinMode(led2, OUTPUT);

}

void loop() {

  unsigned long currentMillis = millis();

  switch (state) {

    case 0:   // LED1 ON for 0.5 sec

      digitalWrite(led1, HIGH);
      digitalWrite(led2, LOW);

      if (currentMillis - previousMillis >= 500) {

        previousMillis = currentMillis;

        digitalWrite(led1, LOW);

        state = 1;

      }

      break;

    case 1:   // LED2 ON for 1 sec

      digitalWrite(led1, LOW);
      digitalWrite(led2, HIGH);

      if (currentMillis - previousMillis >= 1000) {

        previousMillis = currentMillis;

        digitalWrite(led2, LOW);

        state = 0;

      }

      break;
  }

}