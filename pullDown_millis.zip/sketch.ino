const int ledPin = 4;
const int buttonPin = 2;

bool ledState = false;
bool lastButtonState = LOW;   // Previous button state

unsigned long lastDebounceTime = 0;
const unsigned long debounceDelay = 300;

void setup() {
  pinMode(ledPin, OUTPUT);
  pinMode(buttonPin, INPUT);   // External 10k pull-down resistor
}

void loop() {

  bool currentButtonState = digitalRead(buttonPin);

  // Detect Rising Edge (LOW -> HIGH)
  if (lastButtonState == LOW && currentButtonState == HIGH) {

    // Check if debounce time has passed
    if (millis() - lastDebounceTime >= debounceDelay) {

      ledState = !ledState;
      digitalWrite(ledPin, ledState);

      // Save the current time
      lastDebounceTime = millis();
    }
  }

  // Store current state for next loop
  lastButtonState = currentButtonState;
}