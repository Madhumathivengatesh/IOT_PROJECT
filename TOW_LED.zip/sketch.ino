const int led1 = 2;
const int led2 = 4;

bool led1State = LOW;
bool led2State = LOW;

unsigned long previousMillis1 = 0;
unsigned long previousMillis2 = 0;

const unsigned long interval1 = 1000; 
const unsigned long interval2 = 500;  

void setup() {
  pinMode(led1, OUTPUT);
  pinMode(led2, OUTPUT);
}

void loop() {

  unsigned long currentMillis = millis();

  if (currentMillis - previousMillis1 >= interval1) {
    previousMillis1 = currentMillis;
    led1State = !led1State;
    digitalWrite(led1, led1State);
  }

  if (currentMillis - previousMillis2 >= interval2) {
    previousMillis2 = currentMillis;
    led2State = !led2State;
    digitalWrite(led2, led2State);
  }

}