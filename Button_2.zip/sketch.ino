const int ledPin = 2;
const int buttonPin = 4;

bool ledState = false;
bool lastButtonState = HIGH;

void setup() {
  pinMode(ledPin, OUTPUT);
  pinMode(buttonPin, INPUT_PULLUP);

  digitalWrite(ledPin, LOW);
}

void loop() {
  bool buttonState = digitalRead(buttonPin);

  // Detect button press
  if (lastButtonState == HIGH && buttonState == LOW) {
    ledState = !ledState;           // Toggle LED
    digitalWrite(ledPin, ledState);

    delay(200); // Simple debounce
  }

  lastButtonState = buttonState;
}